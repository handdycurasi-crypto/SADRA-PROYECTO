#include <iostream> // Permite usar cout y cin para mostrar y recibir datos.
#include <fstream> // Permite trabajar con archivos de texto.
#include <string> // Permite usar variables de tipo string.
#include <vector> // Permite usar vectores para guardar varios anuncios.
using namespace std; // Permite usar cout, cin, string y vector sin escribir std::.

class ResultadoAnalisis { // Define la clase que guardar� el resultado del an�lisis.
private: // Indica que los atributos solo se pueden usar dentro de la clase.
    string categoria; // Guarda la categor�a detectada del anuncio.
    string intencion; // Guarda la intenci�n detectada del anuncio.
    string riesgo; // Guarda el nivel de riesgo del anuncio.
    string recomendacion; // Guarda la recomendaci�n preventiva.

public: // Indica que los m�todos se pueden usar desde fuera de la clase.
    ResultadoAnalisis() { // Constructor vac�o de la clase ResultadoAnalisis.
        categoria = "No analizado"; // Inicializa la categor�a con un valor por defecto.
        intencion = "No analizado"; // Inicializa la intenci�n con un valor por defecto.
        riesgo = "No analizado"; // Inicializa el riesgo con un valor por defecto.
        recomendacion = "No analizado"; // Inicializa la recomendaci�n con un valor por defecto.
    } // Termina el constructor vac�o.

    ResultadoAnalisis(string c, string i, string r, string rec) { // Constructor con par�metros.
        categoria = c; // Asigna el valor recibido a la categor�a.
        intencion = i; // Asigna el valor recibido a la intenci�n.
        riesgo = r; // Asigna el valor recibido al riesgo.
        recomendacion = rec; // Asigna el valor recibido a la recomendaci�n.
    } // Termina el constructor con par�metros.

    string getCategoria() { // M�todo para obtener la categor�a.
        return categoria; // Devuelve la categor�a.
    } // Termina el m�todo getCategoria.

    string getIntencion() { // M�todo para obtener la intenci�n.
        return intencion; // Devuelve la intenci�n.
    } // Termina el m�todo getIntencion.

    string getRiesgo() { // M�todo para obtener el riesgo.
        return riesgo; // Devuelve el riesgo.
    } // Termina el m�todo getRiesgo.

    string getRecomendacion() { // M�todo para obtener la recomendaci�n.
        return recomendacion; // Devuelve la recomendaci�n.
    } // Termina el m�todo getRecomendacion.
}; // Termina la clase ResultadoAnalisis.

class Anuncio { // Define la clase Anuncio.
private: // Indica que los atributos son privados.
    int id; // Guarda el identificador del anuncio.
    string rutaImagen; // Guarda la ruta de la imagen del anuncio.
    string descripcion; // Guarda la descripci�n escrita del anuncio.
    ResultadoAnalisis resultado; // Guarda el resultado del an�lisis del anuncio.

public: // Indica que los m�todos son p�blicos.
    Anuncio(int idAnuncio, string ruta, string desc) { // Constructor de la clase Anuncio.
        id = idAnuncio; // Asigna el id recibido al atributo id.
        rutaImagen = ruta; // Asigna la ruta recibida al atributo rutaImagen.
        descripcion = desc; // Asigna la descripci�n recibida al atributo descripcion.
    } // Termina el constructor.

    int getId() { // M�todo para obtener el id.
        return id; // Devuelve el id.
    } // Termina el m�todo getId.

    string getRutaImagen() { // M�todo para obtener la ruta de la imagen.
        return rutaImagen; // Devuelve la ruta de la imagen.
    } // Termina el m�todo getRutaImagen.

    string getDescripcion() { // M�todo para obtener la descripci�n.
        return descripcion; // Devuelve la descripci�n.
    } // Termina el m�todo getDescripcion.

    void setResultado(ResultadoAnalisis r) { // M�todo para asignar el resultado del an�lisis.
        resultado = r; // Guarda el resultado recibido.
    } // Termina el m�todo setResultado.

    ResultadoAnalisis getResultado() { // M�todo para obtener el resultado.
        return resultado; // Devuelve el resultado del an�lisis.
    } // Termina el m�todo getResultado.

    void mostrar() { // M�todo para mostrar los datos del anuncio.
        cout << "\nANUNCIO ANALIZADO" << endl; // Muestra un t�tulo.
        cout << "ID: " << id << endl; // Muestra el id del anuncio.
        cout << "Ruta de imagen: " << rutaImagen << endl; // Muestra la ruta de la imagen.
        cout << "Descripcion: " << descripcion << endl; // Muestra la descripci�n del anuncio.
        cout << "Categoria: " << resultado.getCategoria() << endl; // Muestra la categor�a.
        cout << "Intencion: " << resultado.getIntencion() << endl; // Muestra la intenci�n.
        cout << "Riesgo: " << resultado.getRiesgo() << endl; // Muestra el riesgo.
        cout << "Recomendacion: " << resultado.getRecomendacion() << endl; // Muestra la recomendaci�n.
    } // Termina el m�todo mostrar.
}; // Termina la clase Anuncio.

class Clasificador { // Define una clase base abstracta.
public: // Indica que el m�todo ser� p�blico.
    virtual ResultadoAnalisis analizar(string texto) = 0; // M�todo virtual puro para aplicar polimorfismo.
}; // Termina la clase Clasificador.

class ClasificadorReglas : public Clasificador { // Define una clase derivada que hereda de Clasificador.
public: // Indica que los m�todos son p�blicos.
    ResultadoAnalisis analizar(string texto) override { // Sobrescribe el m�todo analizar.
        int puntos = 0; // Crea un contador de se�ales sospechosas.

        if (texto.find("gana dinero") != string::npos) puntos++; // Suma un punto si encuentra la frase gana dinero.
        if (texto.find("dinero rapido") != string::npos) puntos++; // Suma un punto si encuentra dinero rapido.
        if (texto.find("dinero r�pido") != string::npos) puntos++; // Suma un punto si encuentra dinero r�pido con tilde.
        if (texto.find("solo por hoy") != string::npos) puntos++; // Suma un punto si encuentra solo por hoy.
        if (texto.find("urgente") != string::npos) puntos++; // Suma un punto si encuentra urgente.
        if (texto.find("deposita") != string::npos) puntos++; // Suma un punto si encuentra deposita.
        if (texto.find("whatsapp") != string::npos) puntos++; // Suma un punto si encuentra whatsapp.
        if (texto.find("inversion") != string::npos) puntos++; // Suma un punto si encuentra inversion.
        if (texto.find("inversi�n") != string::npos) puntos++; // Suma un punto si encuentra inversi�n con tilde.
        if (texto.find("verifica tus datos") != string::npos) puntos++; // Suma un punto si encuentra verifica tus datos.
        if (texto.find("cuenta bloqueada") != string::npos) puntos++; // Suma un punto si encuentra cuenta bloqueada.

        if (puntos >= 4) { // Verifica si el anuncio tiene muchas se�ales sospechosas.
            return ResultadoAnalisis("Oferta o pago sospechoso", "Urgente / persuasiva", "Alto", "No realizar pagos ni ingresar enlaces sin verificar la fuente."); // Devuelve riesgo alto.
        } // Termina el if de riesgo alto.
        else if (puntos >= 2) { // Verifica si el anuncio tiene algunas se�ales sospechosas.
            return ResultadoAnalisis("Mensaje posiblemente sospechoso", "Persuasiva", "Medio", "Revisar la fuente del anuncio antes de interactuar."); // Devuelve riesgo medio.
        } // Termina el else if de riesgo medio.
        else { // Se ejecuta si hay pocas se�ales sospechosas.
            return ResultadoAnalisis("Sin se�ales fuertes", "Neutral", "Bajo", "No se detectaron se�ales fuertes, pero se recomienda verificar la informaci�n."); // Devuelve riesgo bajo.
        } // Termina el else de riesgo bajo.
    } // Termina el m�todo analizar.
}; // Termina la clase ClasificadorReglas.

class GestorAnuncios { // Define la clase que administra los anuncios.
private: // Indica que los atributos son privados.
    vector<Anuncio> anuncios; // Guarda una lista de anuncios.
    Clasificador* clasificador; // Guarda un puntero a la clase base Clasificador.

public: // Indica que los m�todos son p�blicos.
    GestorAnuncios(Clasificador* c) { // Constructor que recibe un clasificador.
        clasificador = c; // Guarda el clasificador recibido.
    } // Termina el constructor.

    void registrarAnuncio() { // M�todo para registrar y analizar un anuncio.
        string ruta; // Variable para guardar la ruta de la imagen.
        string descripcion; // Variable para guardar la descripci�n.
        int id = anuncios.size() + 1; // Genera un id seg�n la cantidad de anuncios registrados.

        cin.ignore(); // Limpia el salto de l�nea pendiente en la entrada.
        cout << "Ingrese la ruta de la imagen: "; // Pide la ruta de la imagen.
        getline(cin, ruta); // Lee la ruta de la imagen.
        cout << "Ingrese la descripcion del anuncio: "; // Pide la descripci�n.
        getline(cin, descripcion); // Lee la descripci�n completa.

        Anuncio anuncio(id, ruta, descripcion); // Crea un objeto Anuncio.
        ResultadoAnalisis resultado = clasificador->analizar(descripcion); // Analiza la descripci�n usando polimorfismo.
        anuncio.setResultado(resultado); // Asigna el resultado al anuncio.
        anuncios.push_back(anuncio); // Guarda el anuncio en el vector.
        guardarHistorial(anuncio); // Guarda el anuncio en el historial.
        anuncio.mostrar(); // Muestra el resultado del an�lisis.
    } // Termina el m�todo registrarAnuncio.

    void mostrarHistorial() { // M�todo para mostrar todos los anuncios guardados en memoria.
        if (anuncios.empty()) { // Verifica si no hay anuncios registrados.
            cout << "No hay anuncios registrados." << endl; // Muestra un mensaje si no hay anuncios.
        } // Termina el if.
        else { // Se ejecuta si s� hay anuncios.
            for (int i = 0; i < anuncios.size(); i++) { // Recorre todos los anuncios registrados.
                anuncios[i].mostrar(); // Muestra cada anuncio.
            } // Termina el for.
        } // Termina el else.
    } // Termina el m�todo mostrarHistorial.

    void guardarHistorial(Anuncio anuncio) { // M�todo para guardar un anuncio en un archivo.
        ofstream archivo("../resultados/historial_anuncios.txt", ios::app); // Abre el archivo historial en modo agregar.
        archivo << "ID: " << anuncio.getId() << endl; // Guarda el id.
        archivo << "Ruta de imagen: " << anuncio.getRutaImagen() << endl; // Guarda la ruta.
        archivo << "Descripcion: " << anuncio.getDescripcion() << endl; // Guarda la descripci�n.
        archivo << "Categoria: " << anuncio.getResultado().getCategoria() << endl; // Guarda la categor�a.
        archivo << "Intencion: " << anuncio.getResultado().getIntencion() << endl; // Guarda la intenci�n.
        archivo << "Riesgo: " << anuncio.getResultado().getRiesgo() << endl; // Guarda el riesgo.
        archivo << "Recomendacion: " << anuncio.getResultado().getRecomendacion() << endl; // Guarda la recomendaci�n.
        archivo << "----------------------------------------" << endl; // Guarda una separaci�n.
        archivo.close(); // Cierra el archivo.
    } // Termina el m�todo guardarHistorial.
}; // Termina la clase GestorAnuncios.

int main() { // Funci�n principal del programa.
    ClasificadorReglas clasificadorReglas; // Crea un clasificador por reglas.
    GestorAnuncios gestor(&clasificadorReglas); // Crea un gestor y le pasa el clasificador.
    int opcion; // Variable para guardar la opci�n del men�.

    do { // Inicia un ciclo para mostrar el men� varias veces.
        cout << "\nSADRA - Sistema de Analisis de Anuncios Digitales" << endl; // Muestra el nombre del sistema.
        cout << "1. Registrar y analizar anuncio" << endl; // Muestra la opci�n 1.
        cout << "2. Mostrar historial" << endl; // Muestra la opci�n 2.
        cout << "3. Salir" << endl; // Muestra la opci�n 3.
        cout << "Seleccione una opcion: "; // Pide una opci�n.
        cin >> opcion; // Lee la opci�n.

        if (opcion == 1) { // Verifica si el usuario eligi� registrar anuncio.
            gestor.registrarAnuncio(); // Llama al m�todo para registrar y analizar.
        } // Termina el if de opci�n 1.
        else if (opcion == 2) { // Verifica si el usuario eligi� mostrar historial.
            gestor.mostrarHistorial(); // Muestra el historial.
        } // Termina el else if de opci�n 2.
        else if (opcion == 3) { // Verifica si el usuario eligi� salir.
            cout << "Saliendo del sistema..." << endl; // Muestra mensaje de salida.
        } // Termina el else if de opci�n 3.
        else { // Se ejecuta si la opci�n no es v�lida.
            cout << "Opcion no valida." << endl; // Muestra mensaje de error.
        } // Termina el else.
    } while (opcion != 3); // Repite el men� mientras la opci�n sea diferente de 3.

    return 0; // Finaliza el programa correctamente.
} // Termina la funci�n principal.
